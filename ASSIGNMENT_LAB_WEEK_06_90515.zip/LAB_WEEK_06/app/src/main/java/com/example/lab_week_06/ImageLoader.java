package com.example.lab_week_06;

import android.widget.ImageView;

public interface ImageLoader {
    void loadImage(String imageUrl, ImageView imageView);
}


