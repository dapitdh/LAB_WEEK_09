package com.example.lab_week_06.model

enum class Gender {
    Female, Male, Unknown
}
