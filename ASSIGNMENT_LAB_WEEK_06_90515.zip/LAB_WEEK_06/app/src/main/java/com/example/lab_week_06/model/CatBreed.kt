package com.example.lab_week_06.model

enum class CatBreed {
    BalineseJavanese,
    ExoticShorthair,
    AmericanCurl,
    Bengal,
    BritishShorthair,
    MaineCoon,
    Siamese,
    Ragdoll,
    Abyssinian,
    Birman,
    Sphynx,
    NorwegianForestCat,
    TurkishVan,
    ScottishFold,
    Persian,
    Burmese,
    DevonRex,
    Savannah,
    Oriental,
    Tonkinese
}