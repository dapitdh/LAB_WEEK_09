package com.example.lab_week_05.model

data class CatBreedData(
    val name: String,
    val temperament: String
)